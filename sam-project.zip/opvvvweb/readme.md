Statistic and analytical module

This is used to show charts coming from vufind installation. It takes vufind query and transforms it to solr shape and then use solarium library to run the query. It is based on nette library and chart.js library for charting

Installation

Use composer to install all the needed libraries. After installation set up new solr connection in solr presenter
