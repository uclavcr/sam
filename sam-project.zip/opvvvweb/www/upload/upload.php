<?php
	require 'vendor/autoload.php';
	use Google\Cloud\Storage\StorageClient;
	use Google\Cloud\Core\Exception\GoogleException;
	
	if(isset($_POST['submit']))
	{
			if(isset($_FILES['userfile']))
			{
				$errors= array();
				$storage = new StorageClient(['keyFilePath' => 'virtualtraining-dev-f72b773ed3b9.json']);
				$bucket = $storage->bucket('rouvy-video-upload-bucket'); 
				$newname = date("Y-M-d") . "_" . $_FILES['userfile']['name'];

				// Upload a file to the bucket.
				// try {
				// 	$bucket->upload(
				// 			fopen($_FILES['userfile']['name'], 'r'),
				// 			['name' => $newname,
				// 			 'resumable' => true
				// 			]
				// 	);
				// } catch (GoogleException $ex) {
    		// 	// $ex->getMessage(); // handle the failure
				// 	echo "problem uploading: ";
				// 	echo $ex->getMessage();
				// 	die();
				// }
				$uploader = $bucket->getResumableUploader(
					fopen($_FILES['userfile']['tmp_name'], 'r'),
								['name' => $newname,
								 'resumable' => true
								]
				);

				try {
				    $object = $uploader->upload();
				} catch (GoogleException $ex) {
				    $resumeUri = $uploader->getResumeUri();
				    $object = $uploader->resume($resumeUri);
						echo "There was a problem uploading file: ";
						echo $ex->getMessage();
						die();
				}
				
				echo "Upload was successful";
			}
	}

	?>

<html>

<body>
		<form action="" method="post" enctype="multipart/form-data"> Send this file:
				<p/> <input name="userfile" type="file" />
				<p/> <input type="submit" name="submit" value="Send files" /> 
		</form>
</body>

</html>
