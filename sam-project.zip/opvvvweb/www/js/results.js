$(document).ready(function() {
  $('#togglemagazintable').click(function(){
      $('#magazintable').toggle('slow');
      $(this).text(function(i, text){
        return text === "Zobraz tabulku výsledků" ? "Skryj tabulku výsledků" : "Zobraz tabulku výsledků";
      })
  });
  $('#togglegenrestable').click(function(){
      $('#genrestable').toggle('slow');
      $(this).text(function(i, text){
        return text === "Zobraz tabulku výsledků" ? "Skryj tabulku výsledků" : "Zobraz tabulku výsledků";
      })
  });
  $('#toggleyearstable').click(function(){
      $('#yearstable').toggle('slow');
      $(this).text(function(i, text){
        return text === "Zobraz tabulku výsledků" ? "Skryj tabulku výsledků" : "Zobraz tabulku výsledků";
      })
  });
  $('#togglesubjectstable').click(function(){
      $('#subjectstable').toggle('slow');
      $(this).text(function(i, text){
        return text === "Zobraz tabulku výsledků" ? "Skryj tabulku výsledků" : "Zobraz tabulku výsledků";
      })
  });
  $('#togglesubjects_alltable').click(function(){
      $('#subjects_alltable').toggle('slow');
      $(this).text(function(i, text){
        return text === "Zobraz tabulku výsledků" ? "Skryj tabulku výsledků" : "Zobraz tabulku výsledků";
      })
  });
  $('#toggletopic_corporationstable').click(function(){
      $('#topic_corporationstable').toggle('slow');
      $(this).text(function(i, text){
        return text === "Zobraz tabulku výsledků" ? "Skryj tabulku výsledků" : "Zobraz tabulku výsledků";
      })
  });
  $('#toggletopic_eventstable').click(function(){
      $('#topic_eventstable').toggle('slow');
      $(this).text(function(i, text){
        return text === "Zobraz tabulku výsledků" ? "Skryj tabulku výsledků" : "Zobraz tabulku výsledků";
      })
  });
  $('#toggletopic_thingstable').click(function(){
      $('#topic_thingstable').toggle('slow');
      $(this).text(function(i, text){
        return text === "Zobraz tabulku výsledků" ? "Skryj tabulku výsledků" : "Zobraz tabulku výsledků";
      })
  });
  $('#togglechronologic_termstable').click(function(){
      $('#chronologic_termstable').toggle('slow');
      $(this).text(function(i, text){
        return text === "Zobraz tabulku výsledků" ? "Skryj tabulku výsledků" : "Zobraz tabulku výsledků";
      })
  });
  $('#togglegeographic_termstable').click(function(){
      $('#geographic_termstable').toggle('slow');
      $(this).text(function(i, text){
        return text === "Zobraz tabulku výsledků" ? "Skryj tabulku výsledků" : "Zobraz tabulku výsledků";
      })
  });
  $('#togglegeographictable').click(function(){
      $('#geographictable').toggle('slow');
      $(this).text(function(i, text){
        return text === "Zobraz tabulku výsledků" ? "Skryj tabulku výsledků" : "Zobraz tabulku výsledků";
      })
  });
  $('#toggleinfo_resourcestable').click(function(){
      $('#info_resourcestable').toggle('slow');
      $(this).text(function(i, text){
        return text === "Zobraz tabulku výsledků" ? "Skryj tabulku výsledků" : "Zobraz tabulku výsledků";
      })
  });
  $('#toggleclanguagestable').click(function(){
      $('#languagestable').toggle('slow');
      $(this).text(function(i, text){
        return text === "Zobraz tabulku výsledků" ? "Skryj tabulku výsledků" : "Zobraz tabulku výsledků";
      })
  });
  $('#togglepublisherstable').click(function(){
      $('#publisherstable').toggle('slow');
      $(this).text(function(i, text){
        return text === "Zobraz tabulku výsledků" ? "Skryj tabulku výsledků" : "Zobraz tabulku výsledků";
      })
  });
  $('#toggleauthor_variantstable').click(function(){
      $('#author_variantstable').toggle('slow');
      $(this).text(function(i, text){
        return text === "Zobraz tabulku výsledků" ? "Skryj tabulku výsledků" : "Zobraz tabulku výsledků";
      })
  });
  $('#togglelinked_person_birth_yearstable').click(function(){
      $('#linked_person_birth_yearstable').toggle('slow');
      $(this).text(function(i, text){
        return text === "Zobraz tabulku výsledků" ? "Skryj tabulku výsledků" : "Zobraz tabulku výsledků";
      })
  });
  $('#toggleauthor_birth_yearstable').click(function(){
      $('#author_birth_yearstable').toggle('slow');
      $(this).text(function(i, text){
        return text === "Zobraz tabulku výsledků" ? "Skryj tabulku výsledků" : "Zobraz tabulku výsledků";
      })
  });
  $('#toggleauthor_corporatestable').click(function(){
      $('#author_corporatestable').toggle('slow');
      $(this).text(function(i, text){
        return text === "Zobraz tabulku výsledků" ? "Skryj tabulku výsledků" : "Zobraz tabulku výsledků";
      })
  });
  $('#toggleauthor_rolestable').click(function(){
      $('#author_rolestable').toggle('slow');
      $(this).text(function(i, text){
        return text === "Zobraz tabulku výsledků" ? "Skryj tabulku výsledků" : "Zobraz tabulku výsledků";
      })
  });
  $('#togglerelated_documentstable').click(function(){
      $('#related_documentstable').toggle('slow');
      $(this).text(function(i, text){
        return text === "Zobraz tabulku výsledků" ? "Skryj tabulku výsledků" : "Zobraz tabulku výsledků";
      })
  });
  $('#togglerelated_doc_authorstable').click(function(){
      $('#related_doc_authorstable').toggle('slow');
      $(this).text(function(i, text){
        return text === "Zobraz tabulku výsledků" ? "Skryj tabulku výsledků" : "Zobraz tabulku výsledků";
      })
  });
  $('#toggleauthorstable').click(function(){
      $('#authorstable').toggle('slow');
      $(this).text(function(i, text){
        return text === "Zobraz tabulku výsledků" ? "Skryj tabulku výsledků" : "Zobraz tabulku výsledků";
      })
  });
  $('#togglerelated_doc_relationstable').click(function(){
      $('#related_doc_relationstable').toggle('slow');
      $(this).text(function(i, text){
        return text === "Zobraz tabulku výsledků" ? "Skryj tabulku výsledků" : "Zobraz tabulku výsledků";
      })
  });
  $('#toggleeditionsstable').click(function(){
      $('#editionstable').toggle('slow');
      $(this).text(function(i, text){
        return text === "Zobraz tabulku výsledků" ? "Skryj tabulku výsledků" : "Zobraz tabulku výsledků";
      })
  });
  $('#togglecountriestable').click(function(){
      $('#countriestable').toggle('slow');
      $(this).text(function(i, text){
        return text === "Zobraz tabulku výsledků" ? "Skryj tabulku výsledků" : "Zobraz tabulku výsledků";
      })
  });
  $('#toggleformatstable').click(function(){
      $('#formatstable').toggle('slow');
      $(this).text(function(i, text){
        return text === "Zobraz tabulku výsledků" ? "Skryj tabulku výsledků" : "Zobraz tabulku výsledků";
      })
  });
  $('#togglepublication_placestable').click(function(){
      $('#publication_placestable').toggle('slow');
      $(this).text(function(i, text){
        return text === "Zobraz tabulku výsledků" ? "Skryj tabulku výsledků" : "Zobraz tabulku výsledků";
      })
  });
  $('#togglelanguagestable').click(function(){
      $('#languagestable').toggle('slow');
      $(this).text(function(i, text){
        return text === "Zobraz tabulku výsledků" ? "Skryj tabulku výsledků" : "Zobraz tabulku výsledků";
      })
  });
  $('#toggleoriginal_languagestable').click(function(){
      $('#original_languagestable').toggle('slow');
      $(this).text(function(i, text){
        return text === "Zobraz tabulku výsledků" ? "Skryj tabulku výsledků" : "Zobraz tabulku výsledků";
      })
  });
  $('#toggleeditionstable').click(function(){
      $('#editionstable').toggle('slow');
      $(this).text(function(i, text){
        return text === "Zobraz tabulku výsledků" ? "Skryj tabulku výsledků" : "Zobraz tabulku výsledků";
      })
  });

  $('#togglenapoveda').click(function(){
      $('#napoveda').toggle('slow');
      $(this).text(function(i, text){
        return text === "Zobraz tabulku výsledků" ? "Skryj tabulku výsledků" : "Zobraz tabulku výsledků";
      })
  });

  $("#btn-download-year").click(function () {
      var dataURL = document.getElementById("years-chart-area").toDataURL('image/jpeg');
      $("#btn-download-year").attr("href", dataURL);
  });
  $("#btn-download-author").click(function () {
      var dataURL = document.getElementById("chart-authors-area").toDataURL('image/jpeg');
      $("#btn-download-author").attr("href", dataURL);
  });

  $("#btn-download-author_birth_years").click(function () {
      var dataURL = document.getElementById("author_birth_years-chart-area").toDataURL('image/jpeg');
      $("#btn-download-author_birth_years").attr("href", dataURL);
  });

  $("#btn-download-author_corporates").click(function () {
      var dataURL = document.getElementById("chart-author_corporates-area").toDataURL('image/jpeg');
      $("#btn-download-author_corporates").attr("href", dataURL);
  });

  $("#btn-download-author_roles").click(function () {
      var dataURL = document.getElementById("chart-author_roles-area").toDataURL('image/jpeg');
      $("#btn-download-author_roles").attr("href", dataURL);
  });
  $("#btn-download-subjects_all").click(function () {
      var dataURL = document.getElementById("chart-subjects_all-area").toDataURL('image/jpeg');
      $("#btn-download-subjects_all").attr("href", dataURL);
  });
  $("#btn-download-subjects").click(function () {
      var dataURL = document.getElementById("chart-subjects-area").toDataURL('image/jpeg');
      $("#btn-download-subjects").attr("href", dataURL);
  });
  $("#btn-download-topic_corporations").click(function () {
      var dataURL = document.getElementById("chart-topic_corporations-area").toDataURL('image/jpeg');
      $("#btn-download-topic_corporations").attr("href", dataURL);
  });
  $("#btn-download-topic_events").click(function () {
      var dataURL = document.getElementById("chart-topic_events-area").toDataURL('image/jpeg');
      $("#btn-download-topic_events").attr("href", dataURL);
  });
  $("#btn-download-topic_events").click(function () {
      var dataURL = document.getElementById("chart-topic_events-area").toDataURL('image/jpeg');
      $("#btn-download-topic_events").attr("href", dataURL);
  });
  $("#btn-download-geographic_terms").click(function () {
      var dataURL = document.getElementById("chart-geographic_terms-area").toDataURL('image/jpeg');
      $("#btn-download-geographic_terms").attr("href", dataURL);
  });
  $("#btn-download-topic_things").click(function () {
      var dataURL = document.getElementById("chart-topic_things-area").toDataURL('image/jpeg');
      $("#btn-download-topic_things").attr("href", dataURL);
  });
  $("#btn-download-related_documents").click(function () {
      var dataURL = document.getElementById("chart-related_documents-area").toDataURL('image/jpeg');
      $("#btn-download-related_documents").attr("href", dataURL);
  });
  $("#btn-download-related_doc_authors").click(function () {
      var dataURL = document.getElementById("chart-related_doc_authors-area").toDataURL('image/jpeg');
      $("#btn-download-related_doc_authors").attr("href", dataURL);
  });
  $("#btn-download-related_doc_relations").click(function () {
      var dataURL = document.getElementById("chart-related_doc_relations-area").toDataURL('image/jpeg');
      $("#btn-download-related_doc_relations").attr("href", dataURL);
  });
  $("#btn-download-linked_person_birth_years").click(function () {
      var dataURL = document.getElementById("chart-linked_person_birth_years-area").toDataURL('image/jpeg');
      $("#btn-download-linked_person_birth_years").attr("href", dataURL);
  });
  $("#btn-download-publishers").click(function () {
      var dataURL = document.getElementById("chart-publishers-area").toDataURL('image/jpeg');
      $("#btn-download-publishers").attr("href", dataURL);
  });
  $("#btn-download-countries").click(function () {
      var dataURL = document.getElementById("chart-countries-area").toDataURL('image/jpeg');
      $("#btn-download-countries").attr("href", dataURL);
  });
  $("#btn-download-publication_places").click(function () {
      var dataURL = document.getElementById("chart-publication_places-area").toDataURL('image/jpeg');
      $("#btn-download-publication_places").attr("href", dataURL);
  });
  $("#btn-download-editions").click(function () {
      var dataURL = document.getElementById("chart-editions-area").toDataURL('image/jpeg');
      $("#btn-download-editions").attr("href", dataURL);
  });
  $("#btn-download-languages").click(function () {
      var dataURL = document.getElementById("chart-languages-area").toDataURL('image/jpeg');
      $("#btn-download-languages").attr("href", dataURL);
  });
  $("#btn-download-original_languages").click(function () {
      var dataURL = document.getElementById("chart-original_languages-area").toDataURL('image/jpeg');
      $("#btn-download-original_languages").attr("href", dataURL);
  });
  $("#btn-download-info_resources").click(function () {
      var dataURL = document.getElementById("chart-info_resources-area").toDataURL('image/jpeg');
      $("#btn-download-info_resources").attr("href", dataURL);
  });
  $("#btn-download-formats").click(function () {
      var dataURL = document.getElementById("chart-formats-area").toDataURL('image/jpeg');
      $("#btn-download-formats").attr("href", dataURL);
  });
  // $("#").click(function () {
  //     var dataURL = document.getElementById("chart--area").toDataURL('image/jpeg');
  //     $("#").attr("href", dataURL);
  // });







  $("#btn-download-magazin").click(function () {
      var dataURL = document.getElementById("chart-mag-area").toDataURL('image/jpeg');
      $("#btn-download-magazin").attr("href", dataURL);
  });

  $("#btn-download-genre").click(function () {
      var dataURL = document.getElementById("chart-genres-area").toDataURL('image/jpeg');
      $("#btn-download-genre").attr("href", dataURL);
  });


  $(function(){
    // this marks an active link in query type menu
      var href = window.location.href;
      var field = "querytype";
      var reg = new RegExp( '[?&]' + field + '=([^&#]*)', 'i' );
      var string = reg.exec(href);
      var querytype = string ? string[1] : "year";
      $(".chart_type button").each(function() {
          if(querytype == (this.id)) {
              $(this).closest("button").addClass("active");
          }
      });
  });

  // $(".yearexport").click(function() {
	// 	var export_type = $(this).data('export-type');
  //   $("#year_table").table2csv({
  //     filename: 'table.csv'
  //   });

    // var html =  document.getElementById('yeartable').innerHTML; alert(html);
    // $("table").tableExport();
		// $('yeartable').tableExport({
		// 	type : export_type,
		// 	escape : 'false',
		// 	ignoreColumn: []
		// });
	// });

// $("year_table").tableExport();

$('th').click(function(){
    var table = $(this).parents('table').eq(0);
    var rows = table.find('tr:gt(0)').toArray().sort(comparer($(this).index()));
    this.asc = !this.asc;
    if (!this.asc){rows = rows.reverse();}
    for (var i = 0; i < rows.length; i++){table.append(rows[i]);}
});
function comparer(index) {
    return function(a, b) {
        var valA = getCellValue(a, index), valB = getCellValue(b, index);
        return $.isNumeric(valA) && $.isNumeric(valB) ? valA - valB : valA.toString().localeCompare(valB);
    };
}
function getCellValue(row, index){ return $(row).children('td').eq(index).text(); }

});

function helpdisplayon() {
document.getElementById("helpoverlay").style.display = "block";
}

function helpdisplayoff() {
document.getElementById("helpoverlay").style.display = "none";
}

function changecharttype(charttype) {
  window.location = updateQueryStringParameter(document.URL,"querytype",charttype);
}

function updateQueryStringParameter(uri, key, value) {
      var re = new RegExp("([?&])" + key + "=.*?(&|$)", "i");
      var separator = uri.indexOf('?') !== -1 ? "&" : "?";
      if (uri.match(re)) {
        return uri.replace(re, '$1' + key + "=" + value + '$2');
      }
      else {
        return uri + separator + key + "=" + value;
      }
}

function downloadData(type) {
  window.open(updateDownloadParameter(document.URL,"exporttype",type));
}

function updateDownloadParameter(uri, key, value) {
      var re = new RegExp("([?&])" + key + "=.*?(&|$)", "i");
      var separator = uri.indexOf('?') !== -1 ? "&" : "?";
      if (uri.match(re)) {
        return uri.replace(re, '$1' + key + "=" + value + '$2');
      }
      else {
        return uri + separator + key + "=" + value;
      }
}

// $('th').click(function(){
//     var table = $(this).parents('table').eq(0)
//     var rows = table.find('tr:gt(0)').toArray().sort(comparer($(this).index()))
//     this.asc = !this.asc
//     if (!this.asc){rows = rows.reverse()}
//     for (var i = 0; i < rows.length; i++){table.append(rows[i])}
// })
// function comparer(index) {
//     return function(a, b) {
//         var valA = getCellValue(a, index), valB = getCellValue(b, index)
//         return $.isNumeric(valA) && $.isNumeric(valB) ? valA - valB : valA.toString().localeCompare(valB)
//     }
// }
// function getCellValue(row, index){ return $(row).children('td').eq(index).text() }
