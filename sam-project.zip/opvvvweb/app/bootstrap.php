<?php

require __DIR__ . '/../vendor/autoload.php';

$configurator = new Nette\Configurator;

$configurator->setDebugMode(['127.0.0.1', 'localhost']); // enable for your remote IP
// $configurator->setDebugMode(false);
$configurator->enableTracy(__DIR__ . '/../log');

$configurator->setTimeZone('Europe/Prague');
$configurator->setTempDirectory(__DIR__ . '/../temp');

$configurator->createRobotLoader()
	->addDirectory(__DIR__)
	->addDirectory(__DIR__ . '/../libs')
	->register();

$configurator->addConfig(__DIR__ . '/config/config.neon');
$configurator->addConfig(__DIR__ . '/config/config.local.neon');

$container = $configurator->createContainer();

\Nette\Forms\Container::extensionMethod('addDatePicker', function (Nette\Application\UI\Form $container, $name, $label = NULL, $cols = NULL, $maxLength = NULL, $showFAsD = true, $checker = null) {
	return $container[$name] = new JanTvrdik\Components\DatePicker($label, $cols, $maxLength, $showFAsD, $checker);
});


return $container;
