<?php

namespace App\Presenters;

use Nette;
use Nette\Application\UI;
use Nette\Application\Responses\FileResponse;
use Helpers;
use Tracy\Debugger;
use App\Models\codes;
use Solarium\Client;
use Solarium\Core\Client\Adapter\Curl;
use Symfony\Component\EventDispatcher\EventDispatcher;


class SolrPresenter extends Nette\Application\UI\Presenter
{

  public $countryCodesFilter;

 private $client;

  public function __construct()
  {

  }

  public function renderDefault(string $title = NULL, string $author = NULL, string $order = NULL, string $magazin = NULL,
    string $about = NULL, string $cipher = NULL, string $date_from = NULL, string $date_to = NULL, $page = 1) {
    // $config = include __DIR__ . '/../config/config.php';
    $config = array(
    'endpoint' => array(
        'localhost' => array(
            'scheme' => 'http',
            'host' => 'XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX',
            'port' => 8080,
            'path' => '/',
            'core' => 'biblio',
        )
    )
    );
    $adapter = new Curl();
    $adapter->setTimeout(60);
    $eventDispatcher = new EventDispatcher();
    $this->client = new Client($adapter, $eventDispatcher, $config);
    $query = $this->client->createSelect();
    $this->template->search_phrase = "-";

// print_r("memory start:" . memory_get_usage());

// selects query type
  $querytype = "year";
  $querytypearray = ["year", "author", "subject", "linkeddoc", "publisher", "place", "other"];
  if (!empty($this->getParameter('querytype'))) {
    if (in_array($this->getParameter('querytype'), $querytypearray)) {
      $querytype = $this->getParameter('querytype');
    }
  }
  $this->template->querytype = $querytype;
  $fields = [];
  switch ($querytype) {
    case 'year':
      $fields = ['year_str_mv'];
      break;
    case 'author':
    #chybi role a sifra
      $fields = ['author', 'author_birth_year_str_mv', 'author_role', 'author2_role', 'corporation_author_str_mv'];
      break;
    case 'subject':
    #chybi hodne
      $fields = ['topic', 'topic_person_txt_mv', 'geographic', 'topic_corporation_str_mv', 'topic_event_str_mv',
        'geographic_term_str_mv', 'topic_thing_str_mv', 'chronologic_term_str_mv', 'topical_term_str_mv', 'linked_person_birth_year_str_mv'];
      break;
    case 'linkeddoc':
    #odkazovany dilo, uator od dila, zanr
      $fields = ['related_document_txt_mv', 'related_doc_author_str_mv', 'related_doc_relation_str_mv'];
      break;
    case 'publisher':
    # chybi misto vydani, edice
      $fields = ['publisher', 'publication_place_str_mv', 'edition_str_mv', 'country_str_mv', 'language', 'original_language_str_mv', 'article_resource_txt_mv'];
      break;
    case 'other':
      $fields = ['info_resource_str_mv', 'format', 'genre_str_mv'];
      break;
  }

   if (!empty($this->getParameter('lookfor'))) {
     $this->template->search_phrase = $this->getParameter('lookfor');
     $search = str_replace(" ", "+", $this->getParameter('lookfor'));
     if (!empty($this->getParameter('type'))) {
       $search = str_replace("+NOT+", " NOT ", $search);
       $search = str_replace("+AND+", " AND ", $search);
       $search = str_replace("+OR+", " OR ", $search);
       if ($this->getParameter('type') == "ArticleResource") {
         $search = "article_resource_txt_mv" .":" . $search;
       } else if ($this->getParameter('type') == "Placestr") {
         $search = "publication_place_txt_mv" .":" . $search;
       } else if ($this->getParameter('type') == "Yearstr") {
          $search = str_replace("+TO+", " TO ", $search);
         $search = "year_str_mv" .":" . $search;
       } else if ($this->getParameter('type') == "LinkedResource") {
         $search = "related_document_txt_mv" .":" . $search;
       } else if ($this->getParameter('type') == "Subject") {
         $search = "topic_unstemmed" .":" . $search;
       } else if ($this->getParameter('type') == "PublishPlaceStr") {
         $search = "publication_place_txt_mv" .":" . $search;
       } else if ($this->getParameter('type') == "Title") {
         $search = "title_full_unstemmed" .":" . $search;
       } else if ($this->getParameter('type') == "Author") {
         $search = str_replace("+", "\ ", $search);
         $search = "author" .":" . $search;
       } else {
         $search = "allfields" .":" . $search;
       }
     }
     $query->setQuery($search);
   }

    if (!empty($this->getParameter('filter'))) {
      $search_filters = [];
      foreach ($this->getParameter('filter') as $item) {
        $name = explode(":", $item)[0];
        $search = str_replace('"', "", $item);
        if ($name == "year_str_mv") {
        } else {
          $search = str_replace(" ", "\ ", $search);
          $search = str_replace("[", "\[", $search);
          $search = str_replace("]", "\]", $search);
          $search = str_replace("(", "\(", $search);
          $search = str_replace(")", "\)", $search);
          $search_filters[$name] = isset($search_filters[$name]) ? $search_filters[$name] . " AND " . $item : $item;
        }
      }
      foreach ($search_filters as $key => $value) {
        $query->createFilterQuery($key)->setQuery($value);
      }
      $this->template->search_filter = implode(', ',$search_filters);
    }
    if (!empty($this->getParameter('daterange'))) {
      $rangeName = $this->getParameter('daterange')[0];
      $fromRangeName =  $rangeName . "from";
      $toRangeName =  $rangeName . "to";
      $fromDate = (!empty($this->getParameter($fromRangeName))) ? $this->getParameter($fromRangeName) : "*";
      $toDate = (!empty($this->getParameter($toRangeName))) ? $this->getParameter($toRangeName) : "NOW";
      $facetQuery = $rangeName . ": [" . $fromDate . " TO " . $toDate . "]";
      $query->createFilterQuery($rangeName)->setQuery($facetQuery  );
    }

    if (!empty($this->getParameter('exporttype'))) {
        $resultsPerPage = 75000;
        $fields = ['year_str_mv', 'author', 'author_birth_year_str_mv', 'author_role', 'author2_role', 'corporation_author_str_mv', 'topic', 'topic_person_txt_mv',
        'geographic', 'topic_corporation_str_mv', 'topic_event_str_mv', 'geographic_term_str_mv', 'topic_thing_str_mv', 'chronologic_term_str_mv',
        'topical_term_str_mv', 'linked_person_birth_year_str_mv', 'related_document_txt_mv', 'related_doc_author_str_mv', 'related_doc_relation_str_mv',
        'publisher', 'publication_place_str_mv', 'edition_str_mv', 'country_str_mv', 'language', 'original_language_str_mv', 'article_resource_txt_mv',
        'info_resource_str_mv', 'format', 'genre_str_mv'];
    } else {
      $resultsPerPage = 2000;
    }

    $currentPage = 1;
    $start = microtime(TRUE);
    $query->setRows($resultsPerPage);
    $query->setFields($fields);
    $query->setStart(($currentPage - 1) * $resultsPerPage);
    // print search uril for debugging
    // if(false === Debugger::$productionMode){
    //   print_r($this->client->createRequest($query)->getUri());
    // }
    $resultset = $this->client->select($query);
    $this->template->results_count = $resultset->getNumFound();


    if ($resultset->getNumFound() >= $resultsPerPage) {
      $this->template->toomuchresults = true;
    }
    // $this->template->search_filter = implode(', ',$search_filters);
    // print_r("<br>Memory before analysis: " . memory_get_usage());
    $end = microtime(TRUE);
    // print_r("<br>The query took " . ($end - $start) . " seconds to complete.");
    if (empty($this->getParameter('exporttype'))) {
      $this->analyzeData($resultset, $this->template->results_count, $resultsPerPage);
    } else {
      $this->exportData($resultset, $fields);
    }
    // print_r("<br>Memory after analysis: " . memory_get_usage());
}

  public function analyzeData($results, $resultCount, $resultLimit) {
    $start = microtime(TRUE);
    $magazins = $subjects = $genres = $author_roles = $years = $info_resources = $details =
    $author_corporates = $author_birth_years = $linked_person_birth_years =
    $authors = $publishers = $languages = $subjects_all = $geographic = $formats =
    $original_languages = $publication_places = $topical_terms = $topic_corporations =
    $topic_events = $geographic_terms = $topic_things = $chronologic_terms = $countries =
    $editions = $related_doc_relations = $related_doc_authors = $related_documents = [];
    $this->template->searchByAuthor = 0;
    $translate_array = ['Czech' => 'Čeština', 'Slovak'=>'Slovenština','English'=>'Angličtina', 'German' => 'Němčina', 'Russian' => 'Ruština'];
    $translated = [];

// if there is too much of results, we do not count all the charts data to save cpu time
    $omitSubject = false;
    // docasne vypnuto kvuli testovani
    // TODO nastavit limity
    // if ((int)$resultCount >= 10000) {
    //   $omitSubject = true;
    // }

    foreach ($results as $record) {
      if (!empty($record["year_str_mv"][0])) {
        if (is_numeric($record["year_str_mv"][0])) {
          if ((int)$record["year_str_mv"][0] > 1750) {
            $years[] = (int)$record["year_str_mv"][0];
          }
        }
      }
      if (!empty($record["article_resource_txt_mv"][0])) {
        $magazins[] = $record["article_resource_txt_mv"][0];
      }
      if (!empty($record->info_resource_str_mv)) {
        $info_resources = array_merge($info_resources, $record->info_resource_str_mv);
      }
      if (!empty($record->corporation_author_str_mv)) {
        $author_corporates = array_merge($author_corporates, $record->corporation_author_str_mv);
      }
      if (!empty($record->format)) {
        $formats = array_merge($formats, $record->format);
      }
      if (!empty($record->author_birth_year_str_mv)) {
        if (is_numeric($record["author_birth_year_str_mv"][0])) {
          if ((int)$record["author_birth_year_str_mv"][0] > 1750) {
            $author_birth_years[] = (int)$record["author_birth_year_str_mv"][0];
          }
        }
      }
      if (!empty($record["linked_person_birth_year_str_mv"][0])) {
        // $year = '';
        if (is_numeric($record["linked_person_birth_year_str_mv"][0])) {
          if ((int)$record["linked_person_birth_year_str_mv"][0] > 1750) {
            $linked_person_birth_years[] = (int)$record["linked_person_birth_year_str_mv"][0];
          }
        }
      }
      if (!empty($record->genre_str_mv)) {
        $genres = array_merge($genres,$record->genre_str_mv);
      }
      if (!empty($record->author)) {
        $authors = array_merge($authors,$record->author);
      }
      if (!empty($record->author_role)) {
        $author_roles = array_merge($author_roles,$record->author_role);
      }
      #we need to add those two indexes
      if (!empty($record->author2_role)) {
        $author_roles = array_merge($author_roles,$record->author2_role);
      }
      if ((!empty($record->topic_person_txt_mv)) AND ($omitSubject == false)) {
        $subjects = array_merge($subjects,$record->topic_person_txt_mv);
      }
      if ((!empty($record->topic)) AND ($omitSubject == false)) {
        $subjects_all = array_merge($subjects_all,$record->topic);
      }
      if ((!empty($record->topic_corporation_str_mv)) AND ($omitSubject == false)) {
        $topic_corporations = array_merge($topic_corporations,$record->topic_corporation_str_mv);
      }
      if ((!empty($record->topic_event_str_mv)) AND ($omitSubject == false)) {
        $topic_events = array_merge($topic_events,$record->topic_event_str_mv);
      }
      if ((!empty($record->geographic_term_str_mv)) AND ($omitSubject == false)) {
        $geographic_terms = array_merge($geographic_terms,$record->geographic_term_str_mv);
      }
      if ((!empty($record->topic_thing_str_mv)) AND ($omitSubject == false)) {
        $topic_things = array_merge($topic_things,$record->topic_thing_str_mv);
      }
      if ((!empty($record->chronologic_term_str_mv)) AND ($omitSubject == false)) {
        $chonologic_terms = array_merge($chronologic_terms,$record->chronologic_term_str_mv);
      }
      if (!empty($record->related_document_txt_mv)) {
        $related_documents = array_merge($related_documents,$record->related_document_txt_mv);
      }
      if (!empty($record->related_doc_author_str_mv)) {
        $related_doc_authors = array_merge($related_doc_authors,$record->related_doc_author_str_mv);
      }
      if (!empty($record->related_doc_relation_str_mv)) {
        $related_doc_relations = array_merge($related_doc_relations,$record->related_doc_relation_str_mv);
      }
      if (!empty($record->edition_str_mv)) {
        $editions = array_merge($editions,$record->edition_str_mv);
      }
      if (!empty($record->country_str_mv)) {
        $countries = array_merge($countries,$record->country_str_mv);
      }
      if ((!empty($record->geographic)) AND ($omitSubject == false)) {
        $geographic = array_merge($geographic,$record->geographic);
      }
      if (!empty($record->publisher)) {
        $publishers = array_merge($publishers,$record->publisher);
      }
      if (!empty($record->publication_place_str_mv)) {
        $publication_places = array_merge($publication_places, $record->publication_place_str_mv);
      }
      if (!empty($record->original_language_str_mv)) {
        $original_languages = array_merge($original_languages,$record->original_language_str_mv);
      }
      if (!empty($record->language)) {
        $languages = array_merge($languages,$record->language);
      }
    }
    // $end = microtime(TRUE);
    // print_r("<br>The analyis took " . ($end - $start) . " seconds to complete.");
    if ($years) {
      $this->countDateArray("years", $years);
    }
    if ($magazins) {
      $this->countArray("mag", $magazins);
    }
    if ($genres) {
      $this->countArray("genres", $genres);
    }
    if ($subjects) {
      $this->countArray("subjects", $subjects);
    }
    if ($subjects_all) {
      $this->countArray("subjects_all", $subjects_all);
    }
    if ($topic_corporations) {
      $this->countArray("topic_corporations", $topic_corporations);
    }
    if ($topic_events) {
      $this->countArray("topic_events", $topic_events);
    }
    if ($geographic_terms) {
      $this->countArray("geographic_terms", $geographic_terms);
    }
    if ($topic_things) {
      $this->countArray("topic_things", $topic_things);
    }
    if ($chronologic_terms) {
      $this->countArray("chronologic_terms", $chronologic_terms);
    }
    if ($geographic) {
      $this->countArray("geographic", $geographic);
    }
    if ($formats) {
      $this->countArray("formats", $formats);
    }
    if ($info_resources) {
      $this->countArray("info_resources", $info_resources);
    }
    if ($author_corporates) {
      $this->countArray("author_corporates", $author_corporates);
    }
    if ($author_birth_years) {
      $this->countDateArray("author_birth_years", $author_birth_years);
    }
    if ($linked_person_birth_years) {
      $this->countDateArray("linked_person_birth_years", $linked_person_birth_years);
    }
    if ($authors) {
      $this->countArray("authors", $authors, $translate = false, $transform = true);
    }
    if ($author_roles) {
      # there are many empty values which we are not interested in
      foreach  ($author_roles as $key => $value) {
        if (!empty($value)) {
          $temp_array[] = $value;
        }
      }
      $this->countArray("author_roles", $temp_array);
    }

    if ($publishers) {
      $this->countArray("publishers", $publishers, $translate = false, $transform = false, $transformComma = true );
    }
    if ($publication_places) {
      $this->countArray("publication_places", $publication_places);
    }
    if ($languages) {
      $this->countArray("languages", $languages);
    }
    if ($original_languages) {
      $this->countArray("original_languages", $original_languages);
    }
   if ($related_doc_relations) {
     $this->countArray("related_doc_relations", $related_doc_relations);
   }
   if ($related_doc_authors) {
     $this->countArray("related_doc_authors", $related_doc_authors);
   }
   if ($related_documents) {
     $this->countArray("related_documents", $related_documents);
   }
   if ($countries) {
     $this->countArray("countries", $countries);
   }
   if ($editions) {
     $this->countArray("editions", $editions);
   }
  $end = microtime(TRUE);
  // print_r("<br>The analyis took " . ($end - $start) . " seconds to complete.");

  }

  public function exportData($results, $exportColumns) {
    $type = "columnsArray";
    foreach ($exportColumns as $name) {
      $columnNames[] = \App\Models\codes::$type($name);
    }
    if (empty($search)) { $search = "reserse"; }
    $filename = "tmp/vufind-" . $search . ".txt";
    $fp = fopen($filename, 'wb');
    fputcsv($fp, $columnNames);

    foreach ($results as $result) {
      $csvline = [];
      foreach ($exportColumns as $column) {
        array_push($csvline, implode("|", (array)$result->$column));
      }
      fputcsv($fp, $csvline);
    }
    fclose($fp);

    $httpResponse = $this->context->getService('httpResponse');
    $httpResponse->setHeader('Content-Length', filesize($filename));
    $this->sendResponse(new FileResponse($filename, $filename, 'text/csv'));
  }

  protected function extractSubjects($string): array {
    $pieces = explode('$a', $string);
    $parts = [];
    foreach ($pieces as $piece){
      $parts[] = explode("$", $piece)[0];
    }
    array_shift($parts);
    return $parts;
  }

  function countDateArray($name, $array) {
    if ($array) {
      $dataName = $name . "Occurences";
      $chartName = $name . "Array";
      $countName = $name . "CountArray";
      $occurences = array_count_values($array);
      ksort($occurences);
      #  add zero values here
      $min_year = key($occurences);
      $max_year = key(array_slice($occurences, -1, 1, true));
      foreach(range($min_year, $max_year) as $i) {
        if (!array_key_exists($i, $occurences)) {
          $occurences[$i] = 0;
        }
      }
      ksort($occurences);
      $this->template->$dataName = $occurences;
      $this->template->$chartName = array_keys($occurences);
      $this->template->$countName = array_values($occurences);
    }

  }

  function translateArray($type, $array) {
    foreach ($array as $key => $value) {
        $translated[\App\Models\codes::$type($key)] = $value;
    }
    return $translated;
  }

  function translateinfo_resourcesArray($array) {
    $newarray = [];
    foreach ($array as $key => $value) {
      switch ($key) {
        case 'Soucasna bibliografie (po roce 1945)':
          $newarray["oficiální tisk"] = isset($newarray["oficiální tisk"]) ? $newarray["oficiální tisk"] + $value: $value;
          break;
        case 'Retrospektivni bibliografie (do roku 1945)':
          $newarray["oficiální tisk"] = isset($newarray["oficiální tisk"]) ? $newarray["oficiální tisk"] + $value: $value;
          break;
        case 'Databaze excerpovanych casopisu':
          $newarray["oficiální tisk"] = isset($newarray["oficiální tisk"]) ? $newarray["oficiální tisk"] + $value: $value;
          break;
        case 'Databaze zahranicnich bohemik':
          $newarray["oficiální tisk"] = isset($newarray["oficiální tisk"]) ? $newarray["oficiální tisk"] + $value: $value;
          break;
        case 'Bibliografie internetu':
          $newarray["internet"] = $value;
          break;
        case 'Bohemisticke konsorcium':
        // decided to skip at the end
          // $newarray["Zahraniční bohemika"] = $value;
          break;
        case 'Bibliografie exilu':
          $newarray["exil"] = $value;
          break;
        case 'Bibliografie samizdatu':
          $newarray["samizdat"] = $value;
          break;
        case 'Polonika v ceskem samizdatu':
          $newarray["samizdat"] = isset($newarray["samizdat"]) ? $newarray["samizdat"] + $value: $value;
          break;
        default:
          $newarray[$key] = $value;
          break;
      }
    }
    return $newarray;
  }

  function countArray($name, $array, $translate = false, $transform = false, $transformComma = false) {
      $dataName = $name . "Occurences";
      $chartName = $name . "Array";
      $countName = $name . "CountArray";
      $arrayOccurences = array_count_values($array);
      arsort($arrayOccurences);

      if ($transform) {
        $translated = [];
        foreach ($arrayOccurences as $key => $value) {
           $lastWordAr = explode(" ", $key);
           $lastWord = array_pop($lastWordAr);
           if (preg_match_all( "/[0-9]/", $lastWord)>5) {
                   $key = str_replace($lastWord, '',  $key);
                   $translated[$key] = $value;
           } else {
             $translated[$key] = $value;
           }
        }
        $arrayOccurences = $translated;
      }
      if ($transformComma) {
        foreach ($arrayOccurences as $key => $value) {
          $key = rtrim($key, ",");
          $translated[$key] = $value;
        }
        $arrayOccurences = $translated;
      }
      if ($name == "author_roles") {
        $arrayOccurences = $this->translateArray("roleArray", $arrayOccurences);
      }
      if ($name == "languages" OR $name == "original_languages") {
        $arrayOccurences = $this->translateArray("languageArray", $arrayOccurences);
      }
      if ($name == "countries") {
        $arrayOccurences = $this->translateArray("countryCodeArray", $arrayOccurences);
      }
      if ($name == "formats") {
        $arrayOccurences = $this->translateArray("formatsArray", $arrayOccurences);
      }
      if ($name == "info_resources") {
        $arrayOccurences = $this->translateinfo_resourcesArray($arrayOccurences);
      }
      if ($name == "editions") {
        foreach ($arrayOccurences as $key => $value) {
          $key = rtrim($key, ";");
          $translated[$key] = $value;
        }
        $arrayOccurences = $translated;
      }

      $this->template->$dataName = $arrayOccurences;
      $arrayOccurencesSliced = array_slice($arrayOccurences,0,20);
      $this->template->$chartName = array_keys($arrayOccurencesSliced);
      $this->template->$countName = array_values($arrayOccurencesSliced);
  }
}
